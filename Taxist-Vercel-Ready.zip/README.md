# Taxist Professional Homepage

Open `index.html` in a browser.

This homepage includes:
- Responsive professional landing page
- Sticky navigation
- Product search UI
- Taxist feature cards
- Product-cost insight preview
- Three-step workflow
- Call-to-action section
- Mobile responsive layout

Next: connect the search UI to the GST calculator, product database, price comparison sources, local pricing, and manufacturer-history data.
