# Taxist — Vercel Ready

This project is prepared for deployment on Vercel.

## Deploy
1. Extract this ZIP, or upload/import the project to Vercel.
2. In Vercel, choose **Add New → Project**.
3. Import the project/repository.
4. Vercel should detect the framework automatically.
5. Deploy.

For a Vite/static project, the build output is `dist`.

## Important
Do not upload `node_modules`; Vercel installs dependencies from `package.json`.
